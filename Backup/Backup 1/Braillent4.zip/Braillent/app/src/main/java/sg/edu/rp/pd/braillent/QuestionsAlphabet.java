package sg.edu.rp.pd.braillent;

public class QuestionsAlphabet {

    private String mQuestions [] = {
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",
            "Alphabet",

    };

    private String mImages [] = {
            "braille_a",
            "braille_b",
            "braille_c",
            "braille_d",
            "braille_e",
            "braille_f",
            "braille_g",
            "braille_h",
            "braille_i",
            "braille_j",
            "braille_k",
            "braille_l",
            "braille_m",
            "braille_n",
            "braille_o",
            "braille_p",
            "braille_q",
            "braille_r",
            "braille_s",
            "braille_t",
            "braille_u",
            "braille_v",
            "braille_w",
            "braille_x",
            "braille_y",
            "braille_z",
    };


    private String mChoices [][] = {
            {"A", "Z", "F", "G"}, // A
            {"E", "J", "B", "L"}, // B
            {"B", "I", "C", "L"}, // C
            {"M", "D", "O", "P"}, // D
            {"E", "U", "C", "D"}, // E
            {"E", "F", "G", "X"}, // F
            {"I", "J", "G", "Y"}, // G
            {"M", "H", "O", "Z"}, // H
            {"I", "K", "R", "D"}, // I
            {"J", "F", "R", "H"}, // J
            {"I", "K", "V", "L"}, // K
            {"M", "V", "Q", "L"}, // L
            {"A", "Q", "M", "D"}, // M
            {"E", "N", "G", "W"}, // N
            {"I", "J", "O", "L"}, // O
            {"M", "N", "P", "Z"}, // P
            {"Q", "E", "S", "D"}, // Q
            {"E", "R", "D", "H"}, // R
            {"S", "J", "F", "L"}, // S
            {"G", "N", "O", "T"}, // T
            {"E", "S", "N", "U"}, // U
            {"C", "F", "V", "H"}, // V
            {"I", "W", "K", "N"}, // W
            {"M", "X", "O", "P"}, // X
            {"A", "B", "M", "Y"}, // Y
            {"C", "F", "Q", "Z"}, // Z
    };



    private String mCorrectAnswers[] =
            {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};




    public String getQuestion(int i) {
        String question = mQuestions[i];
        return question;
    }

    public String getImage(int i) {
        String image = mImages[i];
        return image;
    }


    public String getChoice1(int i) {
        String choice0 = mChoices[i][0];
        return choice0;
    }


    public String getChoice2(int i) {
        String choice1 = mChoices[i][1];
        return choice1;
    }

    public String getChoice3(int i) {
        String choice2 = mChoices[i][2];
        return choice2;
    }

    public String getChoice4(int i) {
        String choice3 = mChoices[i][3];
        return choice3;
    }

    public String getCorrectAnswer(int i) {
        String answer = mCorrectAnswers[i];
        return answer;
    }

    public int getQuestionLength() {
        int length = mQuestions.length;
        return length;
    }

}