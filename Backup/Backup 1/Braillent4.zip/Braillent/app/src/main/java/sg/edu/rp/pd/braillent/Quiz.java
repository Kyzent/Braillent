package sg.edu.rp.pd.braillent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Quiz extends AppCompatActivity {

    private QuestionsAlphabet mQuestionLibrary = new QuestionsAlphabet();

    private TextView mScoreView;
    private TextView mQuestionView;
    private Button mButtonChoice1;
    private Button mButtonChoice2;
    private Button mButtonChoice3;
    private Button mButtonChoice4;
    private ImageView mImage;

    private String mAnswer;
    private int mScore = 0;
    private int mQuestionNumber = 0;
    private int questionLength = mQuestionLibrary.getQuestionLength();

    Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        random = new Random();

        mScoreView = findViewById(R.id.textViewScore);
        mImage = findViewById(R.id.imageViewQuiz);
        mQuestionView = findViewById(R.id.textViewQuestion);
        mButtonChoice1 = findViewById(R.id.buttonChoice1);
        mButtonChoice2 = findViewById(R.id.buttonChoice2);
        mButtonChoice3 = findViewById(R.id.buttonChoice3);
        mButtonChoice4 = findViewById(R.id.buttonChoice4);

        NextQuestion(random.nextInt(questionLength));

        mButtonChoice1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if (mButtonChoice1.getText().equals(mAnswer)){
                    mScore = mScore + 1;
                    updateScore(mScore);
                    NextQuestion(random.nextInt(questionLength));
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(Quiz.this, "Wrong", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                }
            }
        });

        mButtonChoice2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if (mButtonChoice2.getText().equals(mAnswer)){
                    mScore = mScore + 1;
                    updateScore(mScore);
                    NextQuestion(random.nextInt(questionLength));
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(Quiz.this, "Wrong", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                }
            }
        });

        mButtonChoice3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if (mButtonChoice3.getText().equals(mAnswer)){
                    mScore = mScore + 1;
                    updateScore(mScore);
                    NextQuestion(random.nextInt(questionLength));
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(Quiz.this, "Wrong", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                }
            }
        });

        mButtonChoice4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if (mButtonChoice4.getText().equals(mAnswer)){
                    mScore = mScore + 1;
                    updateScore(mScore);
                    NextQuestion(random.nextInt(questionLength));
                    Toast.makeText(Quiz.this, "Correct", Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(Quiz.this, "Wrong", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                }
            }
        });

    }

    private void GameOver() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Quiz.this);
        alertDialogBuilder
                .setMessage("Game Over")
                .setCancelable(false)
                .setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(getApplicationContext(), Quiz.class));
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        System.exit(0);
                    }
                });
        alertDialogBuilder.show();
    }


    private void updateScore(int points) {
        mScoreView.setText("" + mScore);
    }

    private void NextQuestion(int num){
        mQuestionView.setText(mQuestionLibrary.getQuestion(num));
        mImage.setImageResource(getResources().getIdentifier(mQuestionLibrary.getImage(num), "drawable", getPackageName()));
        mButtonChoice1.setText(mQuestionLibrary.getChoice1(num));
        mButtonChoice2.setText(mQuestionLibrary.getChoice2(num));
        mButtonChoice3.setText(mQuestionLibrary.getChoice3(num));
        mButtonChoice4.setText(mQuestionLibrary.getChoice4(num));

        mAnswer = mQuestionLibrary.getCorrectAnswer(num);
    }

}