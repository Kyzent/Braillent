package sg.edu.rp.pd.braillent;

public class QuestionsAlphabet {

    private String mQuestions [] = {
            "Question 1 / 26",
            "Question 2 / 26",
            "Question 3 / 26",
            "Question 4 / 26",
            "Question 5 / 26",
            "Question 6 / 26",
            "Question 7 / 26",
            "Question 8 / 26",
            "Question 9 / 26",
            "Question 10 / 26",
            "Question 11 / 26",
            "Question 12 / 26",
            "Question 13 / 26",
            "Question 14 / 26",
            "Question 15 / 26",
            "Question 16 / 26",
            "Question 17 / 26",
            "Question 18 / 26",
            "Question 19 / 26",
            "Question 20 / 26",
            "Question 21 / 26",
            "Question 22 / 26",
            "Question 23 / 26",
            "Question 24 / 26",
            "Question 25 / 26",
            "Question 26 / 26",
            ""

    };

    private String mImages [] = {
            "braille_a",
            "braille_e",
            "braille_i",
            "braille_o",
            "braille_u",
            "braille_x",
            "braille_y",
            "braille_z",
            "braille_k",
            "braille_r",
            "braille_l",
            "braille_v",
            "braille_q",
            "braille_w",
            "braille_t",
            "braille_p",
            "braille_s",
            "braille_d",
            "braille_f",
            "braille_g",
            "braille_b",
            "braille_c",
            "braille_n",
            "braille_j",
            "braille_m",
            "braille_h",
            ""
    };


    private String mChoices [][] = {
            {"A", "D", "F", "G"}, // A
            {"E", "J", "K", "L"}, // E
            {"B", "I", "K", "L"}, // I
            {"M", "N", "O", "P"}, // O
            {"A", "U", "C", "D"}, // U
            {"E", "F", "G", "X"}, // X
            {"I", "J", "K", "Y"}, // Y
            {"M", "N", "O", "Z"}, // Z
            {"A", "K", "R", "D"}, // K
            {"L", "F", "R", "H"}, // R
            {"I", "J", "V", "L"}, // L
            {"M", "V", "Q", "P"}, // V
            {"A", "Q", "W", "D"}, // Q
            {"E", "T", "G", "W"}, // W
            {"I", "J", "T", "L"}, // T
            {"M", "N", "P", "Z"}, // P
            {"A", "B", "S", "D"}, // S
            {"E", "B", "D", "H"}, // D
            {"I", "J", "F", "L"}, // F
            {"G", "N", "O", "P"}, // G
            {"A", "B", "N", "D"}, // B
            {"C", "F", "G", "H"}, // C
            {"I", "J", "K", "N"}, // N
            {"M", "J", "O", "P"}, // J
            {"A", "B", "M", "D"}, // M
            {"C", "F", "Q", "H"}, // H
            {"","","",""}
    };



    private String mCorrectAnswers[] =
            {"A", "E", "I", "O", "U", "X", "Y", "Z", "K", "R", "L", "V", "Q", "W", "T", "P", "S", "D", "F", "G", "B", "C", "N", "J", "M", "H", ""};




    public String getQuestion(int i) {
        String question = mQuestions[i];
        return question;
    }

    public String getImage(int i) {
        String image = mImages[i];
        return image;
    }


    public String getChoice1(int i) {
        String choice0 = mChoices[i][0];
        return choice0;
    }


    public String getChoice2(int i) {
        String choice1 = mChoices[i][1];
        return choice1;
    }

    public String getChoice3(int i) {
        String choice2 = mChoices[i][2];
        return choice2;
    }

    public String getChoice4(int i) {
        String choice3 = mChoices[i][3];
        return choice3;
    }

    public String getCorrectAnswer(int i) {
        String answer = mCorrectAnswers[i];
        return answer;
    }

}
